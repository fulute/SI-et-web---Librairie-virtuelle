You have received an email from {<?php echo config_item('tags_trigger'); ?>:name}

IP Address: {<?php echo config_item('tags_trigger'); ?>:sender_ip}
Operating System: {<?php echo config_item('tags_trigger'); ?>:sender_os}
User Agent: {<?php echo config_item('tags_trigger'); ?>:sender_agent}

{<?php echo config_item('tags_trigger'); ?>:comment}