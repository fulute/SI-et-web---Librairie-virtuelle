<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$config['staff_width'] = 150;
$config['staff_height'] = 200;
$config['supplier_width'] = 150;
$config['supplier_height'] = 200;
$config['product_width'] = 200;
$config['product_height'] = 200;

?>