<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Pole %s smí obsahovat pouze písmena, číslice, podtržítka, tečky a pomlčky.";
$lang['decimal']			= "Pole %s smí obsahovat pouze desetinná čísla.";
$lang['csrf_bad_token']			= "Neplatný CSRF token";

/* End of file extra_validation_lang.php */