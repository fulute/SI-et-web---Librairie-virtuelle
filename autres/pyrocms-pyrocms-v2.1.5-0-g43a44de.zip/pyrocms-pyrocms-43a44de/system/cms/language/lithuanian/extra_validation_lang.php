<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= " %s laukelyje galima naudoti tik angliškos abėcėlės simbolius, pabraukimus, taškus ir brūkšnius.";
$lang['decimal']				= "%s laukelyje galima naudoti tik  dešimtainiai skaičiai.";
$lang['csrf_bad_token']			= "Negaliojantis CSRF Token";

/* End of file extra_validation_lang.php */