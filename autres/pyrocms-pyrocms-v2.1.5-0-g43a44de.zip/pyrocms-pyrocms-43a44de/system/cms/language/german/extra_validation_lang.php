<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash'] = "Das Feld %s darf nur alphanumerische Zeichen, Unterstrich, Punkt und Bindestrich enthalten.";
$lang['decimal']        = "Das Feld %s darf nur Dezimalzahlen enthalten.";
$lang['csrf_bad_token'] = "Ung&uuml;ltiger CSRF Schl&uuml;ssel";

/* End of file extra_validation_lang.php */