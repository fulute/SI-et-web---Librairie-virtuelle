<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'Intro';
$lang['step1']	=	'Žingsnis #1';
$lang['step2']	=	'Žingsnis #2';
$lang['step3']	=	'Žingsnis #3';
$lang['step4']	=	'Žingsnis #4';
$lang['final']	=	'Paskutinis žingsnis';

$lang['installer.passwords_match']		= "Slaptažodžiai sutampa."; #translate
$lang['installer.passwords_dont_match']	= "Slaptažodžiai nesutampa."; #translate

/* End of file global_lang.php */