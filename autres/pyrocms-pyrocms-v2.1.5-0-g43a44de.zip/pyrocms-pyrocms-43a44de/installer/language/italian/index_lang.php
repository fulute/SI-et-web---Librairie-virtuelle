<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		=	'Benvenuto';
$lang['thankyou']	= 	'Grazie per aver scelto PyroCMS!';
$lang['text']		=	'Installare PyroCMS è molto semplice, segui i passaggi ed i messaggi a schermo. In caso di problemi nell\'installazione del sistema non preoccuparti, ti verrà spiegato cosa fare.';
$lang['step1'] 		= 'Passo 1';
$lang['link']		= 'Vai al primo passo';
 