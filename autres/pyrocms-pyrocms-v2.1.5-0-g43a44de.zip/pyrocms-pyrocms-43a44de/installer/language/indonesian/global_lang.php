<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'Pendahuluan';
$lang['step1']	=	'Langkah #1';
$lang['step2']	=	'Langkah #2';
$lang['step3']	=	'Langkah #3';
$lang['step4']	=	'Langkah #4';
$lang['final']	=	'Langkah Terakhir';

$lang['installer.passwords_match']		= "Password Cocok.";
$lang['installer.passwords_dont_match']	= "Password Tidak Cocok.";

/* End of file global_lang.php */
