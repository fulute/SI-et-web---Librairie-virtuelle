<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		=	'Selamat Datang';
$lang['thankyou']	= 	'Terima kasih telah memilih PyroCMS!';
$lang['text']		=	'Menginstall PyroCMS sangat mudah, cukup dengan mengikuti langkah demi langkah pesan di layar. Apabila Anda mengalami kendala saat menginstall jangan khawatir, installer ini akan menjelaskan apa yang mesti Anda lakukan.';
$lang['step1'] 		= 'Langkah 1';
$lang['link']		= 'Jalankan langkah pertama';

/* End of file index_lang.php */
