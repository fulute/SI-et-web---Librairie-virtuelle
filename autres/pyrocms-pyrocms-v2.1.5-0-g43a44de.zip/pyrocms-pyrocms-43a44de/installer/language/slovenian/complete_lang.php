<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Čestitamo';
$lang['intro_text']			= 'PyroCMS je sedaj nameščen in pripravljen za delo. Prosimo prijavite se v administracijo s naslednjimi podatki.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Geslo';
$lang['show_password']		= 'Pokaži geslo?';
$lang['outro_text']			= 'Za konec, <strong>izbrišite mapo installer</strong>, če jo pustite na strežniku lahko pride do vdora na vašo spletno stran.';

$lang['go_website']			= 'Pojdi na spletno stran';
$lang['go_control_panel']	= 'Pojdi v administracijo strani';

/* End of file complete_lang.php */
