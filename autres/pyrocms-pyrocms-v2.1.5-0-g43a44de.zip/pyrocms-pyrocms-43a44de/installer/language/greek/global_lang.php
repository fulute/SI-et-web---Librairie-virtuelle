<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'Εισαγωγή';
$lang['step1']	=	'Βήμα #1';
$lang['step2']	=	'Βήμα #2';
$lang['step3']	=	'Βήμα #3';
$lang['step4']	=	'Βήμα #4';
$lang['final']	=	'Τελικό Βήμα';

$lang['installer.passwords_match']		= "Τα Συνθηματικά Ταιριάζουν.";
$lang['installer.passwords_dont_match']	= "Τα Συνθηματικά Δεν Ταιριάζουν.";

/* End of file global_lang.php */