<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Parabéns';
$lang['intro_text']			= 'Agora que o PyroCMS foi instalado e está pronto para ser usado, você pode utilizar as seguintes informações para entrar no painel de controle.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Senha';
$lang['show_password']		= 'Show Password?'; #translate
$lang['outro_text']			= 'E não se esqueça de <strong>remover o diretório de instalação (<em>./installer</em>) do seu servidor</strong>, caso contrário, algum curioso ou alguém mal intencionado pode se aproveitar dele para tentar desconfigurar o seu site.';

$lang['go_website']			= 'Entrar no site';
$lang['go_control_panel']	= 'Entrar no Painel de Controle';