<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		=	'Bienvenue';
$lang['thankyou']	= 	'Merci d\'avoir choisi PyroCMS !';
$lang['text']		=	'L\'installation de PyroCMS est simple, il vous suffit de suivre les informations étapes par étapes. Dans le cas où vous rencontreriez un problème lors de l\'installation, il vous suffit de suivre les indications à l\'écran qui vous indiqueront la conduite à tenir.';
$lang['step1'] 		= 'Étape 1';
$lang['link']		= 'Passer à la première étape';
