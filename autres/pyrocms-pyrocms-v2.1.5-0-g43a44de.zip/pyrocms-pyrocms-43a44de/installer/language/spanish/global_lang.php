<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro'] = 'Inicio';
$lang['step1'] = 'Paso #1';
$lang['step2'] = 'Paso #2';
$lang['step3'] = 'Paso #3';
$lang['step4'] = 'Paso #4';
$lang['final'] = 'Paso final';

$lang['installer.passwords_match']	= "Las contraseñas coinciden.";
$lang['installer.passwords_dont_match']	= "Las contraseñas no coinciden.";